#include <iostream>
using namespace std;

int sentinelLinearSearch(int arr[], int n, int x) {
  // nyimpen elemen terakhir array
  int last = arr[n - 1];

  // ganti elemen terakhir sama x
  arr[n - 1] = x;

  int i = 0;
  while (arr[i] != x) {
    i++;
  }

  // ngembeliin elemen terakhir ke posisi semula
  arr[n - 1] = last;

  if (i < n - 1 || arr[n - 1] == x) {
    return i;
  }
  return -1;
}

int main() {
  int arr[] = {2, 4, 6, 8, 10, 12, 14, 16, 18, 20};
  int n = sizeof(arr) / sizeof(arr[0]);

  int x = 14;
  int index = sentinelLinearSearch(arr, n, x);

  if (index != -1) {
    cout << "Elemen ditemukan pada index ke- " << index << endl;
  } else {
    cout << "Elemen tidak ditemukan" << endl;
  }
  return 0;
}