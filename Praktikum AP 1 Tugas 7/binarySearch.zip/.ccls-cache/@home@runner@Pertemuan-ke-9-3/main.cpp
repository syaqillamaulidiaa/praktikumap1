#include <iostream>
using namespace std;

int binarySearch(int arr[], int l, int y, int x) {
  while(1 <= y) {
    int m = l + (y - l) / 2;

    if (arr[m] == x)
      return m;

    if (arr[m] < x)
      l = m + 1;
    else
      y = m - 1;
  }
  return -1;
}

int main() {
  int arr[] = {2, 3, 4, 10, 40};
  int n = sizeof(arr)/sizeof(arr[0]);
  int x = 10;
  int result = binarySearch(arr, 0, n-1, x);
  (result == -1) ? cout << "Element tidak ada di array"
  : cout << "Element ada pada index ke- " << result;

  return 0;
}